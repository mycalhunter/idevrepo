<?php
$conn = mysqli_connect("localhost","username","password","db-name");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  else {
    //echo "Connection successful";
  }
?>
