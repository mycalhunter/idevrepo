<!DOCTYPE html>
<html>
<head>
  <title>New Site</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <style>
  html, body {
    background-color: #fff;
    color: black;
    margin: 10px;
  }
  .success {
    padding: 5px;
    background: rgba(165, 250, 176,0.6);
    border: 1px solid rgb(118, 254, 101);
    color: black;
    font-family: "Arial", sans-serif;
    margin-top: 30px;
  }
  .warning {
    padding: 5px;
    background: rgba(250, 249, 114, 0.6);
    border: 1px solid rgb(252, 255, 84);
    color: black;
    font-family: "Arial", sans-serif;
    margin-top: 30px;
  }
  .result {
    display: block;
    border: 1px solid black;
    margin: 5px;
    padding: 5px;
  }
  .input {
    padding: 5px;
    border-radius: 2px;
    border: 1px solid #d9d9d9;
    margin: auto auto 10px auto;
  }
  select {
    width: 80%;
    padding: 5px;
  }
  .submit {
    margin: 10px auto;
    border: 1px solid #a8a8a8;
    padding: 10px 20px;
    border-radius: 3px;
    box-shadow: 2px 2px 3px #cfcfcf;
  }
  .required {
    color:red;
    display: inline-block;
    padding-left: 2px;
    vertical-align:top;
  }
  .header {
    background-color: #181858;
    padding: 10px;
    margin-bottom: 20px;
    color: white;
    border-bottom: 5px solid #e9e9e9;
  }
  @media (max-width:800px) {
    .input {
      width: 80%;
    }
    h1 {
      font-size: 1em;
    }
  }
  </style>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?
include 'connect.php';
$id = $_GET['idcollection'];
$deletename = $_GET['name'];
$delete = "DELETE from collection WHERE idcollection='$id'";
mysqli_query($conn, $delete);

echo "<div class='warning'>";
echo "<p><strong>NOTE: </strong>";
echo "Pop Figure: ".$deletename." removed from Collection :(</p>";
echo "</div>";
echo "<a href='/newsite/index.php'>Return</a>";
?>
</body>
</html>
