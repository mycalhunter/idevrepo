<?
include 'connect.php';

$show = "SELECT idcollection, numcollection, name, groupcollection, popimage FROM collection ORDER BY numcollection ASC";
$result = mysqli_query($conn, $show);
$rowcount=mysqli_num_rows($result);
echo "Current # of POP!&trade; Figures in Collection: " . $rowcount;
$deleteconfirmation = "no";

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        echo "<div class='result'>";

          echo "<div style='width: 70%;display:inline-block;'>";
          echo "<strong>ID:</strong> " . $row["numcollection"]. "<br>";
          echo "<strong>Name:</strong> " . $row["name"]. "<br>";
          echo "<strong>Collection:</strong> " . $row["groupcollection"]. "<br>";
          if (!empty($row["popimage"])) {
            echo "<strong>Large Image:</strong> <a style='text-decoration:none;' target='_blank' href='" . $row["popimage"] . "'>View</a><br>";
          }
          elseif (empty($row["popimage"])){
            echo "<div style='color:red'>No Image</div>";
          }
          echo "<p style='margin-bottom: 0;margin-top: 30px;color:#7d7d7d;'><strong>Remove? </strong> <a style='color:#c52222;text-decoration:none;padding-left:10px;font-weight:bold;' href='deleterow.php?idcollection=" . $row["idcollection"] . "&name=" . $row["name"] . "'>Remove</a></p>";
          echo "</div>";

          echo "<div style='display:inline-block;width: 30%;height: 100%;text-align: right;vertical-align:top;'>";
          echo "<a target='_blank' href='" . $row['popimage'] . "'><img style='max-height: 100px;max-width:100%;' src=" . $row['popimage'] . "></a>";
          echo "</div>";

        echo "</div>";
    }
} else {
    echo "0 results";
}
mysqli_close($conn);
?>
