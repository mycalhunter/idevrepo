<?
$collections = array(
  $adventuretime = "Adventure Time",
  $agentsofshield = "Agents of S.H.I.E.L.D",
  $ageofultron = "Avengers: Age of Ultron",
  $batmanvsuperman = "Batman v. Superman",
  $batmanarkhamasylum = "Batman: Arkham Asylum",
  $fantasticbeasts = "Fantastic Beasts and Where to Find Them",
  $friends = "Friends",
  $gilmoregirls = "Gilmore Girls",
  $guardiansofthegalaxy = "Guardians of the Galaxy",
  $harrypotter = "Harry Potter",
  $collectorcorps = "Marvel: Collector Corps",
  $starwars = "Star Wars",
  $theforceawakens = "Star Wars: The Force Awakens",
  $suicidesquad = "Suicide Squad",
  $superheroes = "Super Heroes",
  $hungergames = "The Hunger Games",
  $justiceleage = "The Justice League",
  $regularshow = "The Regular Show",
  $walkingdead = "The Walking Dead",
  $twilight = "Twilight",
);
?>
