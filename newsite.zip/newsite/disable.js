$(document).ready(function(){
    $('.required.numreq').css('display', 'initial');
    $(('#numcollection')).keyup(function(){
        if($(this).val().length !=0)
            $('.required.numreq').css('display', 'none');
        else
            $('.required.numreq').css('display', 'initial');
    });
    $('.required.namereq').css('display', 'initial');
    $(('#name')).keyup(function(){
        if($(this).val().length !=0)
            $('.required.namereq').css('display', 'none');
        else
            $('.required.namereq').css('display', 'initial');
    });
    $('.required.groupreq').css('display', 'initial');
    $(('#group')).keyup(function(){
        if($(this).val().length !=0)
            $('.required.groupreq').css('display', 'none');
        else
            $('.required.groupreq').css('display', 'initial');
    });
    $('#group').attr('disabled',true);
    $(('#numcollection' && '#name')).keyup(function(){
        if($(this).val().length !=0)
            $('#group').attr('disabled', false);
        else
            $('#group').attr('disabled',true);
    });
    $("#hide").click(function(){
      $(".instructions").slideToggle("slow");
    });
});
