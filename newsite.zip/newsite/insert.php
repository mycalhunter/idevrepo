<?
include 'connect.php';

$numcollection = $_POST["numcollection"];
$name = ucwords($_POST["name"]);
$groupcollection = $_POST["group"];

if (isset($numcollection)) {
  $sql = "INSERT INTO collection (numcollection, name, groupcollection) VALUES ('$numcollection', '$name', '$groupcollection')";
  if (mysqli_query($conn, $sql)) {
    echo "<div class='success'>";
    echo "<p><strong>NOTE: </strong>";
    echo "Entry submitted successfully.</p>";
    echo "</div>";
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
mysqli_close($conn);
?>
