<!DOCTYPE html>
<html>
<head>
  <title>Lauren & Hunter's POP!&trade; Collection List</title>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="http://idevhunter.com/newsite/disable.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<? include 'collections_array.php'; ?>


<a href="http://idevhunter.com/newsite/index.php" title="POP!&trade; Collection List">
  <div class="header">
    <img src="https://images-na.ssl-images-amazon.com/images/I/61UNEJPseuL._SL1001_.jpg">
    <h1>POP!&trade; Collection List</h1>
  </div>
</a>

<div class="hide">
  <p>
    <button id="hide" class="submit">Show/Hide Instructions</button>
  </p>
</div>
<div class="instructions" id="instructions">
  <h3>To Add a POP!&trade; Figure</h3>
  <ol>
    <li>Enter the POP!&trade; Figure's ID Number</li>
    <li>Enter the POP!&trade; Figure's Name/Title</li>
    <li>Select a Collection from the dropdown</li>
    <li>Press Submit</li>
  </ol>
  <br>
  <h3>To Remove a POP!&trade; Figure</h3>
  <ol>
    <li>Locate the POP!&trade; Figure you wish to remove</li>
    <li>Click "Remove" in red</li>
  </ol>
  <p><strong>NOTE: </strong> This cannot be undone.</p>
</div>

<form action="" method="post">
  Number:<br>  <input type="tel" name="numcollection" class="input" id="numcollection"><div class="required numreq">*</div><br>
  Name:<br>  <input type="text" name="name" class="input" id="name"><div class="required namereq">*</div><br>
  Group: <br>
  <select name="group" id="group">
    <option value="">-----------------</option>
    <?
      asort($collections);
      reset($collections);
      foreach($collections as $key => $title):
          echo '<option value="'.$title.'">'.$title.'</option>';
      endforeach;
    ?>
  </select>
  <br>
  <input type="submit" class="submit" value="Add to Collection">
</form>
<?
include 'insert.php';
include 'output.php';
?>
</body>
</html>
